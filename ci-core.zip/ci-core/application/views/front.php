<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to Home Page</title>
<?php //echo base_url(); ?>
	<link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css" type="text/css">
</head>
<body>

<div id="container">
<?php
//print_r($list);
foreach($list as $emp){
	
	echo $emp->emp_name."<br>";
	echo $emp->emp_email;
}
//echo $list[0]->emp_name;
echo "<br>";
print_r($list2);
?>
	<h1>Codeigniter Tutorial</h1>
</div>

</body>
</html>