<?php
class TestModel extends CI_Model{
	
	function test(){
	$query = $this->db->query("SELECT * FROM employee;");
	return $query->result();


		//$array = array(1,2,4,5,6,2);
		//return $array;
	}
	function hello(){
		
		$array2 = array('Home','about','contact');
		return $array2;
	}
}
?>
