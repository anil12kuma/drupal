<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
function index(){
	$this->load->model('TestModel');
	$data['list']=$this->TestModel->test();
	$data['list2']=$this->TestModel->hello();
	$this->load->view('front',$data);
	//echo "My Home Controller";
}
function second(){
	echo "Now i know how to access functions";
}
}
